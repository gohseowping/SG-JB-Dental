// Application data
const treatmentData = [
    {name: "Dental Cleaning", sg_price: "150", jb_price: "50", key: "cleaning"},
    {name: "Tooth Filling", sg_price: "300", jb_price: "100", key: "filling"},
    {name: "Root Canal", sg_price: "1800", jb_price: "600", key: "root-canal"},
    {name: "Dental Crown", sg_price: "1200", jb_price: "400", key: "crown"},
    {name: "Dental Implant", sg_price: "4000", jb_price: "1500", key: "implant"},
    {name: "Tooth Extraction", sg_price: "200-400", jb_price: "80-150", key: "extraction"},
    {name: "Teeth Whitening", sg_price: "400-800", jb_price: "150-300", key: "whitening"},
    {name: "Braces (Metal)", sg_price: "4000-6000", jb_price: "1500-2500", key: "braces"},
    {name: "Wisdom Tooth Removal", sg_price: "800-1500", jb_price: "250-500", key: "wisdom"},
    {name: "Gum Treatment", sg_price: "500-1200", jb_price: "200-400", key: "gum"}
];

const clinicsPreview = [
    {name: "JB Dental Excellence", status: "Verification Complete", rating: "4.8", reviews: "156"},
    {name: "Mahkota Medical Centre", status: "Final Review", rating: "4.7", reviews: "203"},
    {name: "Smile Specialist Clinic", status: "Documents Pending", rating: "4.6", reviews: "89"},
    {name: "Advanced Dental Care", status: "Verification Complete", rating: "4.9", reviews: "234"},
    {name: "Premier Oral Health", status: "Final Review", rating: "4.5", reviews: "127"}
];

const faqData = [
    {
        question: "Is Malaysian dental quality comparable to Singapore?",
        answer: "Our AI verification system ensures all partner clinics meet MDA-SDC cross-certification standards with verified credentials."
    },
    {
        question: "What if I need follow-up care?",
        answer: "Our platform includes guaranteed revisit scheduling with traffic-aware timing and 24/7 support coordination."
    },
    {
        question: "How are payments handled?",
        answer: "We provide transparent pricing with no hidden costs and clear payment processes with our verified clinic partners."
    },
    {
        question: "Are there communication barriers?",
        answer: "All verified clinics have English and Mandarin speaking staff certified through our verification process."
    },
    {
        question: "What about emergency situations?",
        answer: "24/7 support hotline available with emergency coordination and medical support protocols."
    },
    {
        question: "How can I verify clinic hygiene standards?",
        answer: "AI-powered inspection reports include hygiene scoring, sterilization protocols, and real-time facility monitoring. All clinics must meet international hygiene standards."
    },
    {
        question: "Are the dentists properly qualified?",
        answer: "MDA license verification workflow cross-checks qualifications with Malaysian dental board registrations and continuing education records. Only certified professionals are in our network."
    },
    {
        question: "What about travel complications and traffic delays?",
        answer: "Integrated traffic-aware scheduling using real-time traffic data with automatic rescheduling for causeway delays. Smart scheduling reduces travel stress."
    },
    {
        question: "Are there hidden costs I should know about?",
        answer: "Transparent pricing guarantee shows all inclusive costs upfront with no hidden fees or surprise charges. What you see is exactly what you pay."
    },
    {
        question: "Will my insurance cover treatments in Malaysia?",
        answer: "We provide detailed treatment receipts compatible with most Singapore insurance claims and can assist with pre-approval processes. Documentation supports insurance reimbursement."
    }
];

// Application state
let currentPage = 'home';
let currentFilters = {
    treatment: '',
    priceMin: 100,
    priceMax: 5000,
    distance: '',
    rating: ''
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeCalculator();
    initializePriceComparison();
    initializeClinics();
    initializeFAQ();
    initializeModals();
    initializeMobileNav();
    
    // Set initial page from hash or default to home
    const hash = window.location.hash.slice(1);
    if (hash && document.getElementById(hash)) {
        showPage(hash);
    } else {
        showPage('home');
    }
});

// Navigation functionality
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav__link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            showPage(page);
            
            // Update URL hash
            window.history.pushState({page}, '', `#${page}`);
        });
    });
    
    // Handle browser back/forward
    window.addEventListener('popstate', function(e) {
        const page = e.state?.page || 'home';
        showPage(page);
    });
    
    // Scroll to section links
    document.querySelectorAll('[data-scroll]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.getElementById(this.getAttribute('data-scroll'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        currentPage = pageId;
        
        // Update navigation active state
        document.querySelectorAll('.nav__link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-page') === pageId) {
                link.classList.add('active');
            }
        });
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Calculator functionality
function initializeCalculator() {
    const treatmentSelect = document.getElementById('treatment-select');
    const sgPrice = document.getElementById('sg-price');
    const jbPrice = document.getElementById('jb-price');
    const savingsAmount = document.getElementById('savings-amount');
    
    treatmentSelect.addEventListener('change', function() {
        const selectedTreatment = treatmentData.find(t => t.key === this.value);
        
        if (selectedTreatment) {
            sgPrice.textContent = `$${selectedTreatment.sg_price}`;
            jbPrice.textContent = `$${selectedTreatment.jb_price}`;
            
            // Calculate potential savings
            const sgPriceNum = parseInt(selectedTreatment.sg_price.split('-')[0]);
            const jbPriceNum = parseInt(selectedTreatment.jb_price.split('-')[0]);
            const savings = sgPriceNum - jbPriceNum;
            
            savingsAmount.textContent = `Potential savings: $${savings}+`;
        } else {
            sgPrice.textContent = 'Select treatment';
            jbPrice.textContent = 'Select treatment';
            savingsAmount.textContent = 'Select a treatment to see your potential savings';
        }
    });
}

// Price comparison functionality
function initializePriceComparison() {
    const filterTreatment = document.getElementById('filter-treatment');
    const priceMin = document.getElementById('price-min');
    const priceMax = document.getElementById('price-max');
    const priceMinValue = document.getElementById('price-min-value');
    const priceMaxValue = document.getElementById('price-max-value');
    const filterDistance = document.getElementById('filter-distance');
    const filterRating = document.getElementById('filter-rating');
    
    // Initialize price sliders
    if (priceMin && priceMax) {
        priceMin.addEventListener('input', function() {
            currentFilters.priceMin = parseInt(this.value);
            priceMinValue.textContent = `$${this.value}`;
            updateComparisonResults();
        });
        
        priceMax.addEventListener('input', function() {
            currentFilters.priceMax = parseInt(this.value);
            priceMaxValue.textContent = `$${this.value}`;
            updateComparisonResults();
        });
    }
    
    // Initialize other filters
    if (filterTreatment) {
        filterTreatment.addEventListener('change', function() {
            currentFilters.treatment = this.value;
            updateComparisonResults();
        });
    }
    
    if (filterDistance) {
        filterDistance.addEventListener('change', function() {
            currentFilters.distance = this.value;
            updateComparisonResults();
        });
    }
    
    if (filterRating) {
        filterRating.addEventListener('change', function() {
            currentFilters.rating = this.value;
            updateComparisonResults();
        });
    }
    
    // Initial load
    updateComparisonResults();
}

function updateComparisonResults() {
    const treatmentRows = document.getElementById('treatment-rows');
    if (!treatmentRows) return;
    
    let filteredTreatments = treatmentData;
    
    // Apply treatment filter
    if (currentFilters.treatment) {
        filteredTreatments = filteredTreatments.filter(t => t.key === currentFilters.treatment);
    }
    
    // Apply price filter (using JB prices)
    filteredTreatments = filteredTreatments.filter(treatment => {
        const jbPriceStr = treatment.jb_price.toString();
        const jbMax = parseInt(jbPriceStr.includes('-') ? jbPriceStr.split('-')[1] : jbPriceStr);
        const jbMin = parseInt(jbPriceStr.includes('-') ? jbPriceStr.split('-')[0] : jbPriceStr);
        return jbMin >= currentFilters.priceMin && jbMax <= currentFilters.priceMax;
    });
    
    // Generate HTML
    treatmentRows.innerHTML = filteredTreatments.map(treatment => {
        const sgPriceStr = treatment.sg_price.toString();
        const jbPriceStr = treatment.jb_price.toString();
        
        const sgMin = parseInt(sgPriceStr.includes('-') ? sgPriceStr.split('-')[0] : sgPriceStr);
        const jbMin = parseInt(jbPriceStr.includes('-') ? jbPriceStr.split('-')[0] : jbPriceStr);
        
        const avgSavings = sgMin - jbMin;
        
        return `
            <div class="treatment-row">
                <div><strong>${treatment.name}</strong></div>
                <div class="price-sg">$${treatment.sg_price}</div>
                <div class="price-jb">$${treatment.jb_price}</div>
                <div class="savings-amount">~$${avgSavings}</div>
                <div><button class="btn btn--consultation">Book Consultation</button></div>
            </div>
        `;
    }).join('');
    
    // Add event listeners to consultation buttons
    treatmentRows.querySelectorAll('.btn--consultation').forEach(btn => {
        btn.addEventListener('click', function() {
            showSignupModal();
        });
    });
}

// Clinics functionality
function initializeClinics() {
    const clinicGrid = document.getElementById('clinic-grid');
    if (!clinicGrid) return;
    
    clinicGrid.innerHTML = clinicsPreview.map(clinic => {
        const statusClass = clinic.status === 'Verification Complete' ? 'status-complete' :
                           clinic.status === 'Final Review' ? 'status-review' : 'status-pending';
        
        return `
            <div class="clinic-card">
                <div class="clinic-card__header">
                    <h3 class="clinic-name">${clinic.name}</h3>
                    <span class="clinic-status ${statusClass}">${clinic.status}</span>
                </div>
                <div class="clinic-rating">
                    <span>⭐ ${clinic.rating}</span>
                    <span>(${clinic.reviews} reviews)</span>
                </div>
            </div>
        `;
    }).join('');
}

// FAQ functionality
function initializeFAQ() {
    const faqList = document.getElementById('faq-list');
    if (!faqList) return;
    
    faqList.innerHTML = faqData.map((faq, index) => `
        <div class="faq-item-full" data-faq="${index}">
            <button class="faq-question" aria-expanded="false">
                <span>${faq.question}</span>
                <span class="faq-toggle">+</span>
            </button>
            <div class="faq-answer">
                <p>${faq.answer}</p>
            </div>
        </div>
    `).join('');
    
    // Add click handlers for FAQ items
    faqList.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', function() {
            const faqItem = this.closest('.faq-item-full');
            const isOpen = faqItem.classList.contains('open');
            
            // Close all other FAQ items
            faqList.querySelectorAll('.faq-item-full').forEach(item => {
                item.classList.remove('open');
                item.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
            });
            
            // Toggle current item
            if (!isOpen) {
                faqItem.classList.add('open');
                this.setAttribute('aria-expanded', 'true');
            }
        });
    });
}

// Modal functionality
function initializeModals() {
    const modal = document.getElementById('signup-modal');
    const closeBtn = modal.querySelector('.modal__close');
    const overlay = modal.querySelector('.modal__overlay');
    const form = document.getElementById('signup-form');
    
    // Show modal function
    window.showSignupModal = function() {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Focus first input
        const firstInput = modal.querySelector('input');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 100);
        }
    };
    
    // Hide modal function
    function hideModal() {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
    
    // Event listeners
    closeBtn.addEventListener('click', hideModal);
    overlay.addEventListener('click', hideModal);
    
    // Escape key to close
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('show')) {
            hideModal();
        }
    });
    
    // CTA buttons
    document.querySelectorAll('.cta-primary').forEach(btn => {
        btn.addEventListener('click', showSignupModal);
    });
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const treatment = document.getElementById('treatment-interest').value;
        
        // Simple validation
        if (!email || !email.includes('@')) {
            alert('Please enter a valid email address');
            return;
        }
        
        // Simulate form submission
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = 'Joining...';
        submitBtn.disabled = true;
        
        setTimeout(() => {
            // Show success message
            form.innerHTML = `
                <div class="success-message">
                    <h3>Welcome to Priority Access!</h3>
                    <p>You've successfully joined our priority list. We'll notify you as soon as our verified partner clinics are ready in August 2025.</p>
                    <p><strong>Next steps:</strong></p>
                    <ul style="text-align: left; margin-top: 12px;">
                        <li>Check your email for confirmation</li>
                        <li>Follow us for updates on clinic verification progress</li>
                        <li>Get ready for significant savings on dental care!</li>
                    </ul>
                </div>
            `;
            
            // Auto close modal after 5 seconds
            setTimeout(() => {
                hideModal();
                // Reset form for next use
                setTimeout(() => {
                    location.reload();
                }, 500);
            }, 5000);
            
        }, 2000);
    });
}

// Mobile navigation
function initializeMobileNav() {
    const navToggle = document.querySelector('.nav__toggle');
    const navMenu = document.querySelector('.nav__menu');
    
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('show');
            this.classList.toggle('active');
        });
        
        // Close menu when clicking on a link
        navMenu.querySelectorAll('.nav__link').forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('show');
                navToggle.classList.remove('active');
            });
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('show');
                navToggle.classList.remove('active');
            }
        });
    }
}

// Utility functions
function calculateSavings(sgPrice, jbPrice) {
    const sgPriceNum = typeof sgPrice === 'string' && sgPrice.includes('-') 
        ? parseInt(sgPrice.split('-')[0]) 
        : parseInt(sgPrice);
    const jbPriceNum = typeof jbPrice === 'string' && jbPrice.includes('-') 
        ? parseInt(jbPrice.split('-')[0]) 
        : parseInt(jbPrice);
    
    return sgPriceNum - jbPriceNum;
}

function formatPrice(price) {
    return `$${price.toLocaleString()}`;
}

// Smooth scrolling for anchor links
document.addEventListener('click', function(e) {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    }
});

// Add loading states and error handling
function showLoading(element) {
    element.classList.add('loading');
}

function hideLoading(element) {
    element.classList.remove('loading');
}

// Performance optimization: Lazy load content
function lazyLoadContent() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
                observer.unobserve(entry.target);
            }
        });
    });
    
    document.querySelectorAll('.card, .feature, .step').forEach(el => {
        observer.observe(el);
    });
}

// Initialize lazy loading when DOM is ready
document.addEventListener('DOMContentLoaded', lazyLoadContent);

// Add keyboard navigation support
document.addEventListener('keydown', function(e) {
    // Handle tab navigation for modals
    if (e.key === 'Tab') {
        const modal = document.querySelector('.modal.show');
        if (modal) {
            const focusableElements = modal.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            
            if (focusableElements.length > 0) {
                const firstElement = focusableElements[0];
                const lastElement = focusableElements[focusableElements.length - 1];
                
                if (e.shiftKey && document.activeElement === firstElement) {
                    e.preventDefault();
                    lastElement.focus();
                } else if (!e.shiftKey && document.activeElement === lastElement) {
                    e.preventDefault();
                    firstElement.focus();
                }
            }
        }
    }
});

// Analytics and tracking (placeholder for future implementation)
function trackEvent(category, action, label) {
    // Placeholder for analytics tracking
    console.log(`Track: ${category} - ${action} - ${label}`);
}

// Track page views
function trackPageView(page) {
    trackEvent('Navigation', 'Page View', page);
}

// Track CTA clicks
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('cta-primary')) {
        trackEvent('CTA', 'Click', 'Priority Access');
    }
    
    if (e.target.classList.contains('btn--consultation')) {
        trackEvent('CTA', 'Click', 'Free Consultation');
    }
});

// Add form validation helpers
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\+]?[\d\s\-\(\)]{8,}$/;
    return re.test(phone.replace(/\s/g, ''));
}

// Add accessibility improvements
function improveAccessibility() {
    // Add skip link
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'sr-only';
    skipLink.style.position = 'absolute';
    skipLink.style.top = '-40px';
    skipLink.style.left = '6px';
    skipLink.style.transition = 'top 0.3s';
    
    skipLink.addEventListener('focus', function() {
        this.style.top = '6px';
    });
    
    skipLink.addEventListener('blur', function() {
        this.style.top = '-40px';
    });
    
    document.body.insertBefore(skipLink, document.body.firstChild);
    
    // Add main content landmark
    const main = document.querySelector('.main');
    if (main) {
        main.id = 'main-content';
    }
}

// Initialize accessibility improvements
document.addEventListener('DOMContentLoaded', improveAccessibility);